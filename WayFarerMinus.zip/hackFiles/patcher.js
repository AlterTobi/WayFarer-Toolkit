function applyJSONTextPatch(sourceText, jsonPatch){
    function insertIntoString(srcString, pos, value){
        return srcString.slice(0, pos) + value + srcString.slice(pos);
    }
    for (let i = 0; i < jsonPatch.length; i++){
        let patchRule = jsonPatch[i];
        sourceText = insertIntoString(sourceText, patchRule.pos, patchRule.content);
    }
    return sourceText;
}

async function loadPatchedRemoteFile(remoteSrc, patchFile){
    const response = await fetch(extURL + "patches/" + patchFile);
    const jsonPatch = await response.json();
    console.log(jsonPatch);

    fetch(remoteSrc)
    .then(data => data.text())
    .then(
        function scriptBodyPatch(text){
            let patchedSrc = applyJSONTextPatch(text, jsonPatch);
            let patchedScriptElem = document.createElement("script");
            patchedScriptElem.innerText = patchedSrc;
            document.getElementsByTagName("body")[0].appendChild(patchedScriptElem);
            console.log("[WayFarer-] Injected patched version of " + remoteSrc);
        }
    );
}