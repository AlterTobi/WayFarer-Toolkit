console.log("[WF-] test!!");
!function(e) {
    function r(r) {
        for (var n, c, f = r[0], u = r[1], i = r[2], d = 0, b = []; d < f.length; d++)
            c = f[d],
            Object.prototype.hasOwnProperty.call(o, c) && o[c] && b.push(o[c][0]),
                o[c] = 0;
        for (n in u)
            Object.prototype.hasOwnProperty.call(u, n) && (e[n] = u[n]);
        for (l && l(r); b.length; )
            b.shift()();
        return a.push.apply(a, i || []),
            t()
    }
    function t() {
        for (var e, r = 0; r < a.length; r++) {
            for (var t = a[r], n = !0, f = 1; f < t.length; f++)
                0 !== o[t[f]] && (n = !1);
            n && (a.splice(r--, 1),
                e = c(c.s = t[0]))
        }
        return e
    }
    var n = {}
        , o = {
        2: 0
    }
        , a = [];
    function c(r) {
        if (n[r])
            return n[r].exports;
        var t = n[r] = {
            i: r,
            l: !1,
            exports: {}
        };
        return e[r].call(t.exports, t, t.exports, c),
            t.l = !0,
            t.exports
    }
    c.e = function(e) {
        var r = []
            , t = o[e];
        if (0 !== t)
            if (t)
                r.push(t[2]);
            else {
                var n = new Promise(function(r, n) {
                        t = o[e] = [r, n]
                    }
                );
                r.push(t[2] = n);
                var a, f = document.createElement("script");
                f.charset = "utf-8",
                    f.timeout = 120,
                c.nc && f.setAttribute("nonce", c.nc),
                    f.src = function(e) {
                        switch (e){
                            // ReviewModule
                            case 17:
                                loadPatchedRemoteFile("/js/angular/17.0f675f683b6728205c32.js", "17.patch.json");
                                return;
                            // NominationsModule
                            case 20:
                                loadPatchedRemoteFile("/js/angular/20.3181b3093c623f231ac5.js", "20.patch.json");
                                return;
                        }
                        console.log("No patched files for script of ID " + e);

                        return c.p + "" + ({
                            0: "common"
                        }[e] || e) + "." + {
                            0: "ca169e46eee9d62a40af",
                            1: "b69fdbe97e3344bba73c",
                            3: "464b0ca34c1528f2bbdc",
                            4: "80751524167798ccdd6f",
                            5: "045a8b493895aebadf43",
                            6: "5f59c5abc20943016615",
                            10: "22c167d1c801fb5d34bd",
                            11: "57acfa4a1533f3438caa",
                            12: "ae0aba16be6a60a3a085",
                            13: "700a1f0928796de09fe7",
                            14: "64c63088b3ced25c402b",
                            15: "81269a831ae1cb2f97be",
                            16: "3726277ec0b0656f59a2",
                            17: "0f675f683b6728205c32",
                            18: "33a1d7c591ae42e86560",
                            19: "7f971db91015e7d0d6c7",
                            20: "3181b3093c623f231ac5",
                            21: "139b90fe63bf3719e259",
                            22: "b18fa9f24984f2484072",
                            23: "c488ad698af24b71cbe3"
                        }[e] + ".js"
                    }(e);
                var u = new Error;
                a = function(r) {
                    f.onerror = f.onload = null,
                        clearTimeout(i);
                    var t = o[e];
                    if (0 !== t) {
                        if (t) {
                            var n = r && ("load" === r.type ? "missing" : r.type)
                                , a = r && r.target && r.target.src;
                            u.message = "Loading chunk " + e + " failed.\n(" + n + ": " + a + ")",
                                u.name = "ChunkLoadError",
                                u.type = n,
                                u.request = a,
                                t[1](u)
                        }
                        o[e] = void 0
                    }
                }
                ;
                var i = setTimeout(function() {
                    a({
                        type: "timeout",
                        target: f
                    })
                }, 12e4);
                f.onerror = f.onload = a,
                    document.head.appendChild(f)
            }
        return Promise.all(r)
    }
        ,
        c.m = e,
        c.c = n,
        c.d = function(e, r, t) {
            c.o(e, r) || Object.defineProperty(e, r, {
                enumerable: !0,
                get: t
            })
        }
        ,
        c.r = function(e) {
            "undefined" != typeof Symbol && Symbol.toStringTag && Object.defineProperty(e, Symbol.toStringTag, {
                value: "Module"
            }),
                Object.defineProperty(e, "__esModule", {
                    value: !0
                })
        }
        ,
        c.t = function(e, r) {
            if (1 & r && (e = c(e)),
            8 & r)
                return e;
            if (4 & r && "object" == typeof e && e && e.__esModule)
                return e;
            var t = Object.create(null);
            if (c.r(t),
                Object.defineProperty(t, "default", {
                    enumerable: !0,
                    value: e
                }),
            2 & r && "string" != typeof e)
                for (var n in e)
                    c.d(t, n, (function(r) {
                            return e[r]
                        }
                    ).bind(null, n));
            return t
        }
        ,
        c.n = function(e) {
            var r = e && e.__esModule ? function() {
                    return e.default
                }
                : function() {
                    return e
                }
            ;
            return c.d(r, "a", r),
                r
        }
        ,
        c.o = function(e, r) {
            return Object.prototype.hasOwnProperty.call(e, r)
        }
        ,
        c.p = "/js/angular/",
        c.oe = function(e) {
            throw console.error(e),
                e
        }
    ;
    var f = window.webpackJsonp = window.webpackJsonp || []
        , u = f.push.bind(f);
    f.push = r,
        f = f.slice();
    for (var i = 0; i < f.length; i++)
        r(f[i]);
    var l = u;
    t()
}([]);