function init(){
    window.addEventListener('DOMContentLoaded',
        () => {
            // Inject extension URL into local var space
            let extURL = chrome.runtime.getURL("");
            let script = "window.extURL = '" + extURL + "'; window.wfpp = {};";
            let inlineScriptElem = document.createElement("script");
            inlineScriptElem.innerText = script;
            document.getElementsByTagName('body')[0].appendChild(inlineScriptElem);

            // Add file patcher
            let patcherScriptElem = document.createElement('script');
            patcherScriptElem.src = chrome.runtime.getURL("hackFiles/patcher.js");
            document.getElementsByTagName('head')[0].appendChild(patcherScriptElem);

            let runtimeScriptElem = document.createElement('script');
            runtimeScriptElem.src = chrome.runtime.getURL("hackFiles/runtime.hack.js");
            document.getElementsByTagName('head')[0].appendChild(runtimeScriptElem);

            console.log("wf- inject attempie done wowzers");
        }
    )
}

init();